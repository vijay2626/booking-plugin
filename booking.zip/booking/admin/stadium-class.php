<?php

/**
 * Admin class holding all administrative functions for the WordPress plugin LeagueManager
 *
 * @author 	Kolja Schleich
 * @package	LeagueManager
 * @copyright Copyright 2014
 */
class BookingStadiumAdminPanel {

    /**
     * load admin area
     *
     * @param none
     * @return void
     */
    function __construct() {
        
    }

    function BookingStadiumAdminPanel() {
        $this->__construct();
    }

    /**
     * get single stadium
     *
     * @param int $stadium_id
     * @return object
     */
    function getStadium($stadium_id) {
        global $wpdb;

        if (!isset($stadium_id))
            return false;

        $table_name = $wpdb->prefix . 'packagebooking_stadium';
        $stadium = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE `id` = '%d' ", intval($stadium_id)));

        return $stadium;
    }

    /**
     * delete logo from server
     *
     * @param string $image
     * @return void
     *
     */
    function delLogo($image, $db_table, $field_name) {
        global $wpdb;
        $num = $wpdb->get_var($wpdb->prepare("SELECT COUNT(id) FROM {$db_table} WHERE `{$field_name}` = '%s'", basename($image)));
        if ($num == 0) {
            $sizes = array('tiny', 'thumb', 'large', 'full');
            foreach ($sizes AS $size) {
                @unlink($this->getImagePath($image, false, $size));
            } 
        }
    }

    /**
     * set image path in database and upload image to server
     *
     * @param int  $team_id
     * @param string $file
     * @param string $uploaddir
     * @param boolean $overwrite_image
     * @return void | string
     */
    function uploadLogo($team_id, $file, $overwrite = false, $folder, $db_table, $field_name) {
        global $wpdb, $errors;
        
        if ( ! is_object($errors) )
		$errors = new WP_Error();

        // create directory
        wp_mkdir_p($this->getImagePath(false, true));

        $new_file = $this->getImagePath(basename($file['name']), $root = false, $size = 'full', $team_id, $folder, $field_name);
        $info = pathinfo($new_file);
        // make sure that file extension is lowercase
        $new_file = str_replace($info['extension'], strtolower($info['extension']), $new_file);

        if ($this->isSupportedImage($new_file)) {
            if ($file['size'] > 0) {
                if (file_exists($new_file) && !$overwrite) {
                    $wpdb->query($wpdb->prepare("UPDATE {$db_table} SET `{$field_name}` = '%s' WHERE id = '%d'", basename($file['name']), $team_id));
                    $errors->add( 'user_email', __( "<strong>ERROR</strong>: Image exists and is not uploaded. Set the overwrite option if you want to replace it." ), array( 'form-field' => $field_name ) );
                } else {
                    if (move_uploaded_file($file['tmp_name'], $new_file)) {
                        $team = $this->getTeam($team_id);
                        $logo_file = $team->$field_name;

                        $wpdb->query($wpdb->prepare("UPDATE {$db_table} SET `{$field_name}` = '%s' WHERE id = '%d'", basename($file['name']), $team_id));

                        $this->delLogo($logo_file, $db_table, $field_name);

                        $this->createThumbnails($new_file, $overwrite);
                    } else {
                        //parent::setMessage(sprintf(__('The uploaded file could not be moved to %s.'), $this->getImagePath()), true);
                        $errors->add( 'user_email', __( "<strong>ERROR</strong>: The uploaded file could not be moved to %s." ), array( 'form-field' => $field_name ) );
                    }
                }
            }
        } else {
            //parent::setMessage( __('The file type is not supported.','leaguemanager'), true );
            $errors->add( 'user_email', __( "<strong>ERROR</strong>: The file type is not supported.." ), array( 'form-field' => $field_name ) );
        }
    }

    /**
     * returns image directory
     *
     * @param string|false $file
     * @param boolean $root
     * @return string
     */
    function getImagePath($file = false, $root = false, $size = 'full', $id = 0, $folder = 'stadiums') {
            $base = WP_CONTENT_DIR . '/uploads/booking/' . $folder;
	   
        if ($file) {
            if ($size == 'full' || $size == '')
                $file = basename($file);
            else
                $file = $size . "_" . basename($file);

            return $base . '/' . $file;
        } else {
            return $base;
        }
    }

    /**
     * returns url of image directory
     *
     * @param string|false $file image file
     * @param boolean $root
     * @return string
     */
    function getImageUrl($file = false, $root = false, $size = 'full', $id = 0) {
        
        /* if ($root || $id == 0)
          $base = WP_CONTENT_URL . '/uploads/booking';
          else */
        $base = WP_CONTENT_URL . '/uploads/booking/teams';

        if ($file) {
            if ($size == 'full' || $size == '')
                $file = basename($file);
            else
                $file = $size . "_" . basename($file);

            if (file_exists($this->getImagePath($file, $root, '')))
                return esc_url($base . '/' . $file);
            else
                return false;
        } else {
            return esc_url($base);
        }
    }

    /**
     * get supported file types
     *
     * @param none
     * @return array
     */
    function getSupportedImageTypes() {
        return array("jpg", "jpeg", "png", "gif");
    }

    /**
     * get image type of supplied image
     *
     * @param none
     * @return file extension
     */
    function getImageType($image) {
        //global $leaguemanager;
        $file = $this->getImagePath($image);
        $file_info = pathinfo($file);
        return strtolower($file_info['extension']);
    }

    /**
     * check if image type is supported
     *
     * @param none
     * @return boolean
     */
    function isSupportedImage($image) {
        if (in_array($this->getImageType($image), $this->getSupportedImageTypes()))
            return true;

        return false;
    }

    /**
     * crop image
     *
     * @param string $imagepath
     * @return string image url
     */
    function resizeImage($imagepath, $dest_size, $size, $crop = false, $force_resize = false) {
        global $leaguemanager;

        // load image editor
        $image = wp_get_image_editor($imagepath);

        $imageurl = $this->getImageUrl($imagepath);

        // editor will return an error if the path is invalid - save original image url
        if (is_wp_error($image)) {
            return $imageurl;
        } else {
            // create destination file name
            $destination_file = $this->getImagePath($imagepath, false, $size);
            
            $this->destination_file = $destination_file;

            // resize only if the image does not exists
            if (!file_exists($destination_file) || $force_resize) {
                // resize image, optionally with cropping enabled
                $image->resize($dest_size['width'], $dest_size['height'], $crop);
                // save image
                $saved = $image->save($destination_file);
                // return original url if an error occured
                if (is_wp_error($saved)) {
                    return $imageurl;
                }
            }

            $new_img_url = dirname($imageurl) . '/' . basename($destination_file);

            return esc_url($new_img_url);
        }
    }

    /**
     * Create different thumbnail sizes
     *
     * @param string $filename
     * @param string $filename
     */
    function createThumbnails($filename, $force_resize = false) {

        // create different thumbnails
        $sizeArr = $this->imageSizes();
        $sizes = array('tiny' => $sizeArr['tiny_size'], 'thumb' => $sizeArr['thumb_size'], 'large' => $sizeArr['large_size']);

        foreach ($sizes AS $size => $dest_size) {
            $crop = ( $sizeArr['crop_image'][$size] == 1 ) ? true : false;
            $imageurl = $this->resizeImage($filename, $dest_size, $size, $crop, $force_resize);
        }
    }

    function imageSizes() {
        $sizes = array("tiny_size" => array("width" => 40, "height" => 40),
            "thumb_size" => array("width" => 100, "height" => 100),
            "large_size" => array("width" => 1024, "height" => 1024),
            "crop_image" => array('tiny' => 1, 'thumb' => 1, 'medium' => 0, 'large' => 0));
        return $sizes;
    }

}

?>