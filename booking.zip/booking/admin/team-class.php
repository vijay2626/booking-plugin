<?php

/**
 * Admin class holding all administrative functions for the WordPress plugin LeagueManager
 *
 * @author 	Kolja Schleich
 * @package	LeagueManager
 * @copyright Copyright 2014
 */
class ImgurAdminPanel {

    /**
     * load admin area
     *
     * @param none
     * @return void
     */
    function __construct() {
        
    }

    function ImgurAdminPanel() {
        $this->__construct();
    }

    /**
     * get single Imgur
     *
     * @param int $imgur_id
     * @return object
     */
    function getImgur($imgur_id) {
        global $wpdb;

        if (!isset($imgur_id))
            return false;

        $table_name = $wpdb->prefix . 'imgur_details';
        $team = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE `id` = '%d' ", intval($imgur_id)));

        return $imgur;
    }

    /**
     * delete logo from server
     *
     * @param string $image
     * @return void
     *
     */

    /**
     * set image path in database and upload image to server
     *
     * @param int  $team_id
     * @param string $file
     * @param string $uploaddir
     * @param boolean $overwrite_image
     * @return void | string
     */
    /**
     * returns image directory
     *
     * @param string|false $file
     * @param boolean $root
     * @return string
     */
   

    /**
     * returns url of image directory
     *
     * @param string|false $file image file
     * @param boolean $root
     * @return string

    /**
     * get supported file types
     *
     * @param none
     * @return array
     */
 

    /**
     * get image type of supplied image
     *
     * @param none
     * @return file extension
     */
  

    /**
     * check if image type is supported
     *
     * @param none
     * @return boolean
     */
 

    /**
     * crop image
     *
     * @param string $imagepath
     * @return string image url
     */
 
    /**
     * Create different thumbnail sizes
     *
     * @param string $filename
     * @param string $filename
     */

}

?>