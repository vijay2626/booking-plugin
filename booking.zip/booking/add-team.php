<?php
$message = array();
if (isset($_POST['submit'])) {
    global $wpdb;
    $db_table = $wpdb->prefix . 'packagebooking_teams';
    if (($_REQUEST['teamtype'] == "newteam") || (!isset($_GET['league_id']))) { //when the new team form is post.
	if (empty($_POST['team_name'])) {
	    $message[] = "Please enter Team Name.";
	}
	if (empty($_POST['team_info'])) {
	    $message[] = "Please enter Team Info.";
	}
	if (empty($_FILES['team_photo']['name'])) {
	    $message[] = "Please upload Team Photo.";
	}
	if (empty($_FILES['team_logo']['name'])) {
	    $message[] = "Please enter Team Logo.";
	}
    }

    if ($_REQUEST['teamtype'] == "oldteam") { //when the existing team is selected.
	if (empty($_POST['teams']) || ($_POST['teams'] == " ")) {
	    $message[] = "Please Select Team.";
	}
    }
    //die();
    if (count($message) < 1) {
	if (($_REQUEST['teamtype'] == "newteam") || (!isset($_GET['league_id']))) {
	    $teamexists = $wpdb->get_row("SELECT COUNT(*) AS cnt, $db_table.id FROM {$db_table} WHERE wp_packagebooking_teams.team_name='" . $_POST['team_name'] . "'"); //To rectify the creation of duplicate team.
	    $count = $teamexists->cnt;
	    if ($count < 1) {
		$team_name = htmlspecialchars(strip_tags($_POST["team_name"]));
		$team_info = htmlspecialchars(strip_tags($_POST["team_info"]));
		$date_added = current_time('mysql');
		$sql = "INSERT INTO {$db_table} (`team_name`, `team_info`, `added_date`) VALUES ('%s', '%s', '%s')";
		$prepare = $wpdb->prepare($sql, $team_name, $team_info, $date_added);
		$wpdb->query($prepare);
		$team_id = $wpdb->insert_id;
		$folder = 'teams';
		if (isset($_FILES['team_photo']) && $_FILES['team_photo']['name'] != '') {
		    $logo_file = new BookingTeamAdminPanel();
		    $field_name = 'team_photo';
		    $logo_file->uploadLogo($team_id, $_FILES['team_photo'], $overwrite = false, $folder, $db_table, $field_name);
		}
		if (isset($_FILES['team_logo']) && $_FILES['team_logo']['name'] != '') {
		    $logo_file = new BookingTeamAdminPanel();
		    $field_name = 'team_logo';
		    $logo_file->uploadLogo($team_id, $_FILES['team_logo'], $overwrite = false, $folder, $db_table, $field_name);
		}
		if ($_REQUEST['teamtype'] == "newteam") {// When the newteam is created with league id.
		    $league_id = $_GET['league_id'];
		    $table = $wpdb->prefix . 'packagebooking_league_team';
		    $sql = "INSERT INTO {$table} (`league_id`, `team_id`,`status`,`added_date`) VALUES ('%s', '%s', '%s','%s')";
		    $prepare = $wpdb->prepare($sql, $league_id, $team_id, 1, $date_added);
		    $wpdb->query($prepare);
		    echo '<div class="success-msg">Team has been created  successfully And added to the league.</div>';
		} else {
		    echo '<div class="success-msg">Team has been created  successfully.</div>';
		}
	    } else {
		echo '<div class="success-msg">Team Aleady Exists.</div>';
	    }
	} elseif (($_REQUEST['teamtype'] == "oldteam") && (isset($_GET['league_id']))) { // If user select the team from the list.
	    $league_id = $_GET['league_id'];
	    $team_id = $_POST['teams'];
	    $date_added = current_time('mysql');
	    $table = $wpdb->prefix . 'packagebooking_league_team';
	    $sql = "INSERT INTO {$table} (`league_id`, `team_id`,`status`,`added_date`) VALUES ('%s', '%s', '%s','%s')";
	    $prepare = $wpdb->prepare($sql, $league_id, $team_id, 1, $date_added);
	    $wpdb->query($prepare);
	    echo '<div class="success-msg">Team has been successfully added to the League.</div>';
	}
    }
}
?>

<div class="wrap">
    <?php if (!isset($_GET['league_id'])) { ?>
        <h2>Add Team</h2>
	<?php
    } else {
	global $wpdb;
	$getleague = $wpdb->get_row("SELECT wp_packagebooking_league.league_name FROM `wp_packagebooking_league` WHERE wp_packagebooking_league.id=" . $_GET['league_id']); // Get league data
	?>
        <h2><?php echo $getleague->league_name; ?> - Add Team</h2>
	<?php
    }
    if (count($message) > 0) {
	echo' <div class="error">';
	echo implode("<BR>", $message);
	echo '</div>';
    }
    ?>
    <form method="post" action="" enctype="multipart/form-data">
	<div  id="option">

	    <div class="form-group row">
		<label for="league_photo" class="col-sm-1 form-control-label">Add Team</label>
		<div class="col-sm-6">
		    <input type="radio" name="teamtype" value="newteam" id="newteam" <?php
		    if ($_REQUEST['teamtype'] == "newteam") {
			echo"checked";
		    }
		    ?>>
		</div>
	    </div>
	    <div class="form-group row">
		<label for="league_photo" class="col-sm-1 form-control-label">Use Existing Team</label>
		<div class="col-sm-6">
		    <input type="radio" name="teamtype" value="oldteam" id="exteam" <?php
		    if ($_REQUEST['teamtype'] == "oldteam") {
			echo"checked";
		    }
		    ?>>
		</div>
	    </div>
	</div>
        <input type="hidden" name="action" value="booking_add_league" />
	<input type="hidden" name="r_value" value="addnewteam" />
	<div class="addteam">
	    <div class="form-group row">
		<label for="league_name" class="col-sm-2 form-control-label">Team Name:</label>
		<div class="col-sm-6">
		    <input type="text" class="form-control" id="league_name" name="team_name" value="<?php
		    if (isset($_POST['team_name'])) {
			echo $_POST['team_name'];
		    }
		    ?>">
		</div>
	    </div>
	    <div class="form-group row">
		<label for="league_info" class="col-sm-2 form-control-label">Team Info:</label>
		<div class="col-sm-6">
		    <textarea class="form-control" id="league_info" name="team_info"><?php
			if (isset($_POST['team_name'])) {
			    echo $_POST['team_info'];
			}
			?></textarea>
		</div>
	    </div>
	    <div class="form-group row">
		<label for="league_photo" class="col-sm-2 form-control-label">Team Photo:</label>
		<div class="col-sm-6">
		    <input type="file" class="form-control" id="league_photo" name="team_photo">
		    <p>Supported file types: jpg,jpeg,png,gif</p>
		</div>
	    </div>
	    <div class="form-group row">
		<label for="league_logo" class="col-sm-2 form-control-label">Team Logo:</label>
		<div class="col-sm-6">
		    <input type="file" class="form-control" id="league_logo" name="team_logo">
		    <p>Supported file types: jpg,jpeg,png,gif</p>
		</div>
	    </div>
	    <?php wp_nonce_field('add_team_verify'); //prevents your form from being submitted by a user other than an admin        ?>


	</div>
	<div class="selectteam" style="<?php
	if ($_REQUEST['teamtype'] != "oldteam") {
	    echo 'display: none';
	}
	?>">
		 <?php
		 global $wpdb;
		 $select = $wpdb->get_results("SELECT team.team_name,team.id FROM wp_packagebooking_teams team WHERE team.id NOT IN (SELECT team_id FROM wp_packagebooking_league_team WHERE league_id =" . $_GET['league_id'] . ") AND team.status=1");
		 ?>
	    <select name="teams">
		<option value=" ">Select Team</option>
		<?php foreach ($select as $list) { ?>
    		<option value="<?php echo $list->id; ?>"><?php echo $list->team_name; ?></option>
		<?php } ?>
	    </select>
	</div>
	<div class="form-group row">
	    <div class="col-sm-offset-2 col-sm-10">
		<input type="submit" name="submit" class="btn btn-secondary" value="Submit" />
	    </div>
	</div>

    </form>
</div>

<script>
    jQuery(document).ready(function () {
<?php if (isset($_GET['league_id']) && $_REQUEST['teamtype'] == "oldteam") { ?>
    	jQuery('.addteam').hide();
    	//jQuery('.selectteam').hide();
<?php } elseif ((!isset($_GET['league_id'])) && (!$_REQUEST['teamtype'])) { ?>
    	jQuery('#option').hide();
<?php } ?>
    }
    );
    jQuery('input[name=teamtype]').click(function () {
	var rd = jQuery(this).val();
	if (rd == 'newteam') {
	    jQuery('.addteam').show();
	    jQuery('.selectteam').hide();
	}
	if (rd == 'oldteam') {
	    jQuery('.selectteam').show();
	    jQuery('.addteam').hide();
	}
    });
</script>
<!--http://localhost/ticketz/wp-admin/admin.php?page=add-team&subpage=team&league_id=1&season=2016&teamtype=oldteam-->