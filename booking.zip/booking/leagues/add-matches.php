<?php
global $wpdb;
$message = array();
if (isset($_POST['submit'])) {
    $notok = 0;
    for ($p = 0; $p < count($_POST['mydatepicker']); $p++) {
        
        $date = $_POST['mydatepicker'][$p]. " ".$_POST['begin_hour'][$p]. ":" .$_POST['begin_minutes'][$p].":00";
        $home_team = $_POST['home_team'][$p];
        $away_team = $_POST['away_team'][$p];
        $location = $_POST['location'][$p];
        
        if (trim($_POST['mydatepicker'][$p]) == '') {
            $message[] = "Date must me entered on row " . ($p + 1);
        }
        
        if($home_team == $away_team) {
            $message[] = "Home and Away Team can't be same on row " . ($p + 1);
        }                

        //check if when form submitted more than one match is schedule on same date and time
        ///if() {
        //}
        
        //check if this macth is already enter in the system then show message
        $match_count_res = $wpdb->get_row($wpdb->prepare("SELECT COUNT(*) as cnt FROM {$wpdb->prefix}packagebooking_matches WHERE league_id = '%d' AND home_team = '%d' AND away_team = '%d' AND location = '%d' AND date = '%s' ", intval($_POST['league_id']), intval($home_team), intval($away_team), intval($location),  $date ));
        $match_count = $match_count_res->cnt;
        if($match_count > 0) {
            $row = $p+1;
            $message[] = " Row [".$row."] Match is already present. Please check the details";
        }

        if (count($message) < 1) {            
            $data = array("date" => $date, "home_team" => $home_team, "away_team" => $away_team, "location" => $location, "league_id" => $_POST['league_id'], "added_date" => current_time('mysql', 1));
            
           $insert = $wpdb->insert("{$wpdb->prefix}packagebooking_matches", $data);
           if(!$insert) {
               $notok++;
           }
        }
    }//for
    
    
    if ($notok < 1 && count($message) < 1) {  
        echo '<div id="message" class="updated notice is-dismissible"><p>Match data inserted successfully.</p></div>';
    } elseif(count($message) < 1 && $notok > 0) {
        $message[] = '<div id="message" class="updated notice is-dismissible"><p>Some error Occured during Insertion. Please try again.</p></div>';
    }
    
}//submit

$league_id = $_GET['id'];
$manager = new BookingManagerAdminPanel();
$leageInfo = $manager->getLeague($league_id);

//get team count assosicated with league
$team_count_res = $wpdb->get_row($wpdb->prepare("SELECT COUNT(*) as cnt FROM {$wpdb->prefix}packagebooking_league_team WHERE league_id = '%d' ", intval($league_id)));
$team_count = $team_count_res->cnt;

//get all teams
$table_name = $wpdb->prefix . 'packagebooking_teams';
$teamsData = $wpdb->get_results("SELECT id, team_name FROM {$table_name} WHERE status = 1 ");

//get all stadium
$stadium_name = $wpdb->prefix . 'packagebooking_stadium';
$stadiumsData = $wpdb->get_results("SELECT id, CONCAT(stadium_name, ', ', stadium_city, ', ', stadium_country) AS stadium FROM {$stadium_name} WHERE status = 1 ");
?>
<div class="wrap">
    <h1><?php echo $leageInfo->league_name ?> — Add Matches</h1>
    <?php
    if (count($message) > 0) {
        echo' <div class="error">';
        echo implode("<BR>", $message);
        echo '</div>';
    }
    ?>
    <div class="row">
        <div class="col-sm-offset-2 col-sm-10">
            <a href="<?php echo admin_url('admin.php?page=add-team&subpage=team&teamtype=newteam&league_id=' . $league_id) ?>" title="Add Team" class="btn btn-default" role="button">Add Team</a>
            <a href="<?php echo admin_url('admin.php?page=all-league&action=add-matches&id=' . $league_id) ?>" title="Add Matches" class="btn btn-default" role="button">Add Matches</a>
        </div>
    </div>
    <br>
    <div class="row">
        <!-- Forms are NOT created automatically, so you need to wrap the table in one to use features like bulk actions -->
        <form id="match-filter" method="post">
            <!-- For plugins, we also need to ensure that the form posts back to our current page -->
            <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
            <input type="hidden" name="league_id" value="<?php echo $league_id; ?>" />
            <p class="match_info">Note: Matches with different Home and Guest Teams will be added to the database.</p>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Home</th>
                        <th>Guest</th>
                        <th>Location</th>
                        <th>Begin</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    for ($i = 0; $i < ($team_count); $i++) {
                        ?>
                        <tr>
                            <th scope="row">
                                <input required size="10" type="text" name="mydatepicker[<?php echo $i ?>]" id="mydatepicker_<?php echo $i ?>" class="datepicker" value="<?php if(isset($_POST['mydatepicker'][$i])) { echo $_POST['mydatepicker'][$i]; }?>">
                            </th>
                            <td>
                                <select class="form-control" size="1" name="home_team[<?php echo $i ?>]" id="home_team_<?php echo $i ?>">
                                    <?php
                                    foreach ($teamsData as $team) {
                                        $selected1 = "";
                                        if ($team->id == $_POST['home_team'][$i]) {
                                            $selected1 = "selected = 'selected' ";
                                        }
                                        ?>
                                        <option value="<?php echo $team->id ?>" <?php echo $selected1; ?>  ><?php echo $team->team_name ?></option>
                                        <?php
                                    }
                                    ?>
                                </select>
                            </td>
                            <td>
                                <select class="form-control" size="1" name="away_team[<?php echo $i ?>]" id="away_team_<?php echo $i ?>">
                                    <?php
                                    foreach ($teamsData as $team) {
                                        $selected2 = "";
                                        if ($team->id == $_POST['away_team'][$i]) {
                                            $selected2 = "selected = 'selected' ";
                                        }
                                        ?>
                                        <option value="<?php echo $team->id ?>" <?php echo $selected2; ?>  ><?php echo $team->team_name ?></option>
                                        <?php
                                    }
                                    ?>
                                </select>
                            </td>
                            <td>
                                <select class="selectpicker" name="location[<?php echo $i ?>]" id="location_<?php echo $i ?>" data-live-search="true">
                                    <?php
                                    foreach ($stadiumsData as $stadium) {
                                        ?>
                                        <option value="<?php echo $stadium->id ?>" <?php (isset($_POST['away_team'][$i])) ? selected($stadium->id, $_POST['away_team'][$i]) : '' ?> ><?php echo $stadium->stadium ?></option>
                                        <?php
                                    }
                                    ?>
                                </select>

                            </td>
                            <td>
                                <select size="1" name="begin_hour[<?php echo $i ?>]" id="begin_hour_<?php echo $i ?>">
                                    <?php for ($hour = 0; $hour <= 23; $hour++) : ?>
                                        <option value="<?php echo (isset($hour)) ? str_pad($hour, 2, 0, STR_PAD_LEFT) : 00 ?>"<?php (isset($_POST['begin_hour'][$i])) ? selected($hour, $_POST['begin_hour'][$i]) : '' ?>><?php echo (isset($hour)) ? str_pad($hour, 2, 0, STR_PAD_LEFT) : 00 ?></option>
                                    <?php endfor; ?>
                                </select>
                                <select size="1" name="begin_minutes[<?php echo $i ?>]" id="begin_minutes">
                                    <?php for ($minute = 0; $minute <= 60; $minute++) : ?>
                                        <?php if (0 == $minute % 5 && 60 != $minute) : ?>
                                            <option value="<?php echo (isset($minute)) ? str_pad($minute, 2, 0, STR_PAD_LEFT) : 00 ?>"<?php (isset($_POST['begin_minutes'][$i])) ? selected($minute, $_POST['begin_minutes'][$i]) : '' ?>><?php echo (isset($minute)) ? str_pad($minute, 2, 0, STR_PAD_LEFT) : 00 ?></option>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                </select>
                            </td>
                        </tr>
                    <?php }//for }   ?>
                </tbody>
            </table>
            <div class="">
                <div class="col-sm-offset-2 col-sm-10">
                    <?php wp_nonce_field('add_match_verify'); //prevents your form from being submitted by a user other than an admin    ?>
                    <input type="submit" name="submit" class="btn btn-secondary" value="Add Matches" />
                </div>
            </div>
        </form>
    </div>



</div>
<script>
    jQuery(document).ready(function() {
        jQuery('.selectpicker').selectpicker();
    });
</script>