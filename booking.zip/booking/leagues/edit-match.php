<?php
global $wpdb;
$message = array();
if (isset($_POST['submit'])) {
    if (empty($_POST['mydatepicker'])) {
        $message[] = "Please select Date.";
    }

    if (count($message) < 1) {
        $date_str = $_POST['mydatepicker'] . " " . $_POST['begin_hour'] . ":" . $_POST['begin_minutes'];

        $data = array("date" => $date_str, "home_team" => $_POST['home_team'], "away_team" => $_POST['away_team'], "location" => $_POST['location']);
        $wpdb->update("{$wpdb->prefix}packagebooking_matches", $data, array("id" => $_POST['match_id']));

        echo '<div id="message" class="updated notice is-dismissible"><p>Match data updated successfully.</p></div>';
    }
}

$league_id = $_GET['id'];
$match_id = $_GET['edit'];
$manager = new BookingManagerAdminPanel();
$leageInfo = $manager->getLeague($league_id);
$matchInfo = $manager->getMatchDetail($match_id);

$timestamp = strtotime($matchInfo->date);
$date = date("Y-m-d", $timestamp);

$hr = date("H", $timestamp);
$min = date("i", $timestamp);

//get all teams
$table_name = $wpdb->prefix . 'packagebooking_teams';
$teamsData = $wpdb->get_results("SELECT id, team_name FROM {$table_name} WHERE status = 1 ");

//get all stadium
$stadium_name = $wpdb->prefix . 'packagebooking_stadium';
$stadiumsData = $wpdb->get_results("SELECT id, CONCAT(stadium_name, ', ', stadium_city, ', ', stadium_country) AS stadium FROM {$stadium_name} WHERE status = 1 ");
?>
<div class="wrap">

    <h1><?php echo $leageInfo->league_name ?> — Edit Match</h1>
    <?php
    if (count($message) > 0) {
        echo' <div class="error">';
        echo implode("<BR>", $message);
        echo '</div>';
    }
    ?>
    <div class="row">
        <div class="col-sm-offset-2 col-sm-10">
            <a href="<?php echo admin_url('admin.php?page=add-team&subpage=team&teamtype=newteam&league_id=' . $league_id) ?>" title="Add Team" class="btn btn-default" role="button">Add Team</a>
            <a href="<?php echo admin_url('admin.php?page=all-league&action=add-matches&id=' . $league_id) ?>" title="Add Matches" class="btn btn-default" role="button">Add Matches</a>
        </div>
    </div>
    <br>
    <div class="row">
        <!-- Forms are NOT created automatically, so you need to wrap the table in one to use features like bulk actions -->
        <form id="match-filter" method="post">
            <!-- For plugins, we also need to ensure that the form posts back to our current page -->
            <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
            <input type="hidden" name="match_id" value="<?php echo $match_id; ?>" />
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Home</th>
                        <th>Guest</th>
                        <th>Location</th>
                        <th>Begin</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">
                            <input size="10" type="text" name="mydatepicker" id="mydatepicker" class="datepicker" value="<?php echo $date; ?>">
                        </th>
                        <td>
                            <select class="form-control" size="1" name="home_team" id="home_team">
                                <?php
                                foreach ($teamsData as $team) {
                                    $selected1 = "";
                                    if ($team->id == $matchInfo->home_team) {
                                        $selected1 = "selected = 'selected' ";
                                    }
                                    ?>
                                    <option value="<?php echo $team->id ?>" <?php echo $selected1; ?>  ><?php echo $team->team_name ?></option>
                                    <?php
                                }
                                ?>
                            </select>
                        </td>
                        <td>
                            <select class="form-control" size="1" name="away_team" id="away_team">
                                <?php
                                foreach ($teamsData as $team) {
                                    $selected2 = "";
                                    if ($team->id == $matchInfo->away_team) {
                                        $selected2 = "selected = 'selected' ";
                                    }
                                    ?>
                                    <option value="<?php echo $team->id ?>" <?php echo $selected2; ?>  ><?php echo $team->team_name ?></option>
                                    <?php
                                }
                                ?>
                            </select>
                        </td>
                        <td>
                            <select class="selectpicker" name="location" data-live-search="true">
                                <?php
                                foreach($stadiumsData as $stadium) {
                                    ?>
                                <option value="<?php echo $stadium->id?>" <?php (isset($matchInfo->location)) ? selected($stadium->id, $matchInfo->location) : '' ?> ><?php echo $stadium->stadium?></option>
                                <?php
                                }
                                ?>                               
                            </select>

                        </td>
                        <td>
                            <select size="1" name="begin_hour">
                                <?php for ($hour = 0; $hour <= 23; $hour++) : ?>
                                    <option value="<?php echo (isset($hour)) ? str_pad($hour, 2, 0, STR_PAD_LEFT) : 00 ?>"<?php (isset($hr)) ? selected($hour, $hr) : '' ?>><?php echo (isset($hour)) ? str_pad($hour, 2, 0, STR_PAD_LEFT) : 00 ?></option>
                                <?php endfor; ?>
                            </select>
                            <select size="1" name="begin_minutes">
                                <?php for ($minute = 0; $minute <= 60; $minute++) : ?>
                                    <?php if (0 == $minute % 5 && 60 != $minute) : ?>
                                        <option value="<?php echo (isset($minute)) ? str_pad($minute, 2, 0, STR_PAD_LEFT) : 00 ?>"<?php (isset($min)) ? selected($minute, $min) : '' ?>><?php echo (isset($minute)) ? str_pad($minute, 2, 0, STR_PAD_LEFT) : 00 ?></option>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </select>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="">
                <div class="col-sm-offset-2 col-sm-10">
                    <?php wp_nonce_field('edit_match_verify'); //prevents your form from being submitted by a user other than an admin  ?>
                    <input type="submit" name="submit" class="btn btn-secondary" value="Edit Match" />
                </div>
            </div>
        </form>
    </div>



</div>
<script>
    jQuery(document).ready(function() {
        jQuery('.selectpicker').selectpicker();
    });
</script>