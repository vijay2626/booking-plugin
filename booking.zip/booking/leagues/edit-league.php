<?php
$message = array();
$leagueObj = new BookingManagerAdminPanel();
if (isset($_POST['submit'])) {

    global $wpdb;
    $db_table = $wpdb->prefix . 'packagebooking_league';

    if (empty($_POST['league_name'])) {
        $message[] = "Please enter League Name.";
    }
    if (empty($_POST['league_info'])) {
        $message[] = "Please enter League Info.";
    }
    if (empty($_FILES['league_photo']['name'])) {
        $message[] = "Please upload League Photo.";
    }
    if (empty($_FILES['league_logo']['name'])) {
        $message[] = "Please enter League Logo.";
    }
    
    if (count($message) < 1) {
        $league_name = htmlspecialchars(strip_tags($_POST["league_name"]));
        $league_info = htmlspecialchars(strip_tags($_POST["league_info"]));
        //$season = htmlspecialchars(strip_tags($_POST['season']));
        $date_added = current_time('mysql');

        $sql = "INSERT INTO {$db_table} (`league_name`, `league_info`, `added_date`) VALUES ('%s', '%s', '%s')";
        $prepare = $wpdb->prepare($sql, $league_name, $league_info, $date_added);
        $wpdb->query($prepare);
        $team_id = $wpdb->insert_id;

        $folder = 'leagues';
        
        if (isset($_FILES['league_photo']) && $_FILES['league_photo']['name'] != '') {
            $logo_file = new BookingManagerAdminPanel();
            $field_name = 'league_photo';
            $logo_file->uploadLogo($team_id, $_FILES['league_photo'], $overwrite = false, $folder, $db_table, $field_name);
        }
        if (isset($_FILES['league_logo']) && $_FILES['league_logo']['name'] != '') {
            $logo_file = new BookingManagerAdminPanel();
            $field_name = 'league_logo';
            $logo_file->uploadLogo($team_id, $_FILES['league_logo'], $overwrite = false, $folder, $db_table, $field_name);
        }

        echo '<div id="message" class="updated notice is-dismissible"><p>League data updated successfully.</p></div>';
    }
}
$league_id = $_GET['id'];
$leagueInfo = $leagueObj->getLeague($league_id);
?>
<div class="wrap">
    <h2>Edit League</h2>
    <?php
    global $errors;
    if (count($message) > 0) {
        echo' <div class="error">';
        echo implode("<BR>", $message);
        echo '</div>';
    }
    if (isset($errors) && is_wp_error($errors) && count($errors) > 0 ) :
        ?>
        <div class="error">
            <p>
                <?php
                echo implode("</p>\n<p>", $errors->get_error_messages());
                ?>
            </p>
        </div>
    <?php endif; ?>

    <form method="post" action="" enctype="multipart/form-data">
        <input type="hidden" name="action" value="booking_add_league" />
        <div class="form-group row">
            <label for="league_name" class="col-sm-2 form-control-label">League Name:</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" id="league_name" name="league_name" value="<?php if (isset($_POST['league_name'])) {
                echo $_POST['league_name']; } else { echo $leagueInfo->league_name;} ?>" >
            </div>
        </div>
        <div class="form-group row">
            <label for="league_info" class="col-sm-2 form-control-label">League Info:</label>
            <div class="col-sm-6">
                <textarea class="form-control" id="league_info" name="league_info"><?php if (isset($_POST['league_info'])) {
                echo $_POST['league_info'];} else { echo $leagueInfo->league_info;} ?></textarea>
            </div>
        </div>
        <div class="form-group row">
            <label for="league_photo" class="col-sm-2 form-control-label">League Photo:</label>
            <div class="col-sm-6">
                <input type="file" class="form-control" id="league_photo" name="league_photo">
                <p>Supported file types: jpg,jpeg,png,gif</p>
            </div>
        </div>
        <div class="form-group row">
            <label for="league_logo" class="col-sm-2 form-control-label">League Logo:</label>
            <div class="col-sm-6">
                <input type="file" class="form-control" id="league_logo" name="league_logo">
                <p>Supported file types: jpg,jpeg,png,gif</p>
            </div>
        </div>
<!--        <div class="form-group row">
            <label for="league_logo" class="col-sm-2 form-control-label">Season:</label>
            <div class="col-sm-6">
                <input type="text" name="season" id="season" value="" size="8">&nbsp;<span class="setting-description">Usually 4-digit year, e.g. 2008. Can also be any kind of string, e.g. 0809</span>
            </div>
        </div>-->
        <td>

            <?php wp_nonce_field('add_league_verify'); //prevents your form from being submitted by a user other than an admin  ?>

            <div class="form-group row">
                <div class="col-sm-offset-2 col-sm-10">
                    <input type="submit" name="submit" class="btn btn-secondary" value="Submit" />
                </div>
            </div>
    </form>
</div>