<?php
$league_id = $_GET['id'];
$manager = new BookingManagerAdminPanel();
$listTable = new MatchesListTable();
//Fetch, prepare, sort, and filter our data...
$listTable->prepare_items();

$leageInfo = $manager->getLeague($league_id);
?>
<div class="wrap">

    <h1><?php echo $leageInfo->league_name ?></h1>

    <div class="row">
        <div class="col-xs-6 previous">
            <a href="<?php echo admin_url('admin.php?page=add-team&subpage=team&teamtype=newteam&league_id='.$league_id)?>" title="Add Team" class="btn btn-default" role="button">Add Team</a>
            <a href="<?php echo admin_url('admin.php?page=all-league&action=add-matches&id='.$league_id)?>" title="Add Matches" class="btn btn-default" role="button">Add Matches</a>
        </div>        
    </div>
    <h2 class="header">Match Plan</h2>

    <!-- Forms are NOT created automatically, so you need to wrap the table in one to use features like bulk actions -->
    <form id="match-filter" method="get">
        <!-- For plugins, we also need to ensure that the form posts back to our current page -->
        <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
        <!-- Now we can render the completed list table -->
        <?php $listTable->display() ?>
    </form>

</div>
