<?php 
$discount_id = $_REQUEST['discount'];

$delete = mysql_query("delete from wp_discount where discount_id='".$discount_id."'");

if($delete) {
  	echo "<script>window.location='/wp-admin/admin.php?page=list_discount';</script>";
}

?>

