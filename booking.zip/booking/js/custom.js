  jQuery(document).ready(function() {
    jQuery(".datepicker").datepicker({ dateFormat: 'yy-mm-dd' });
    
    setTimeout(function(){ 
    	jQuery(".success-msg").fadeOut();
    	jQuery(".error-msg").fadeOut();

     }, 3000);

  });