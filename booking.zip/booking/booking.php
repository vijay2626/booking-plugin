<?php

/**
 * Plugin Name:       Package Booking
 * Plugin URI:        http://anaisystechnologies.com/
 * Description:       Package Booking System
 * Version:           1.0
 * Author:            Anaisys Technologies
 * Author URI:        http://anaisystechnologies.com/
 */
add_action("admin_menu", "createMyMenus");
add_action('admin_init', 'my_plugin_admin_init');

function my_plugin_admin_init() {
    /* Register our stylesheet. */
    wp_register_style('admin_panel_css', plugin_dir_url(__FILE__) . 'css/custom.css');
    wp_register_style('jquery_ui_css', plugin_dir_url(__FILE__) . 'css/jquery-ui.css');
    wp_register_style('bootstrap_css', plugin_dir_url(__FILE__) . 'css/bootstrap.min.css');
    wp_register_style('bs_select_css', plugin_dir_url(__FILE__) . 'css/bootstrap-select.min.css');
    wp_register_style('data-table_css', plugin_dir_url(__FILE__) . 'css/jquery.dataTables.css');
    wp_register_style('datatable_css', plugin_dir_url(__FILE__) . 'css/jquery.dataTables_themeroller.css');
}

function my_plugin_admin_styles() {
    /* It will be called only on your plugin admin page, enqueue our stylesheet here   */
    wp_enqueue_style('admin_panel_css');
    wp_enqueue_style('jquery_ui_css');
    wp_enqueue_style('bootstrap_css');
    wp_enqueue_style('bs_select_css');
    wp_enqueue_style('data-table_css');
    wp_enqueue_style('datatable_css');
}

function createMyMenus() {
    add_menu_page('Package Booking', 'Package Booking', 61, plugin_dir_url('booking.php'), '');
    add_submenu_page(plugin_dir_url('booking.php'), 'League', 'All League', 0, 'all-league', 'Package_Booking_League');
    add_submenu_page(plugin_dir_url('booking.php'), 'Add League', 'Add League', 0, 'add-league', 'Package_Add_League');
    add_submenu_page(plugin_dir_url('booking.php'), 'Teams', 'All Teams', 0, 'teams', 'Package_Booking_Teams');
    add_submenu_page(plugin_dir_url('booking.php'), 'Teams', 'Add Teams', 0, 'add-team', 'Package_Add_Team');
    add_submenu_page(plugin_dir_url('booking.php'), 'Stadium', 'All Stadium', 0, 'stadium', 'Package_Booking_Stadium');
    add_submenu_page(plugin_dir_url('booking.php'), 'Flights', 'All Flights', 0, 'flights', 'Package_Booking_Flights');
    add_submenu_page(plugin_dir_url('booking.php'), 'Games', 'All Games', 0, 'games', 'Package_Booking_Games');
    add_submenu_page(plugin_dir_url('booking.php'), 'Hotels', 'All Hotels', 0, 'hotels', 'Package_Booking_Hotels');
    add_submenu_page(plugin_dir_url('booking.php'), 'Tickets', 'All Tickets', 0, 'tickets', 'Package_Booking_Tickets');
    add_submenu_page(plugin_dir_url('booking.php'), 'Packages', 'All Packages', 0, 'packages', 'Package_Booking_Packages');

    add_action('admin_print_styles', 'my_plugin_admin_styles');
}

function Package_Booking_League() {


    include('leagues/match-list-class.php');

    if (isset($_REQUEST['page']) && $_REQUEST['action'] == 'edit') {
        include('leagues/edit-match.php');
    } elseif (isset($_REQUEST['page']) && $_REQUEST['action'] == 'edit-league') {
        include('leagues/edit-league.php');
    } elseif (isset($_REQUEST['page']) && $_REQUEST['action'] == 'add-matches') {
        include('leagues/add-matches.php');
    } elseif (isset($_REQUEST['page']) && $_REQUEST['action'] == 'plan') {
        include('leagues/plan-matches.php');
    } else {
        include('league.php');
    }
}

function Package_Add_League() {
    include('add-league.php');
}

function Package_Add_Team() {
    include('add-team.php');
}

function Package_Booking_Teams() {
    if (isset($_REQUEST['page']) && $_REQUEST['edit-team'] == 1) {
        include('edit-team.php');
    } elseif (isset($_REQUEST['page']) && $_REQUEST['delete-team'] == 1) {
        include('delete-team.php');
    } else {
        include('teams.php');
    }
}

function Package_Booking_Stadium() {
    include('admin/stadium-class.php');
    include('stadium.php');
}

function Package_Booking_Flights() {
    include('flights.php');
}

function Package_Booking_Games() {
    include('games.php');
}

function Package_Booking_Hotels() {
    include('hotels.php');
}

function Package_Booking_Tickets() {
    include('tickets.php');
}

function Package_Booking_Packages() {
    include('packages.php');
}

function aad_load_scripts($hook) {
    //global $aad_settings;
    if (!is_admin())
        return;
    wp_enqueue_script('aad-jquery-ui', plugin_dir_url(__FILE__) . 'js/jquery-ui.js', array('jquery'));
    wp_enqueue_script('data-table-js', plugin_dir_url(__FILE__) . 'js/jquery.dataTables.min.js', array('jquery'));
    wp_enqueue_script('bootstrap-js', plugin_dir_url(__FILE__) . 'js/bootstrap.min.js', array('jquery'));
    wp_enqueue_script('bootstrap-select-js', plugin_dir_url(__FILE__) . 'js/bootstrap-select.min.js', array('jquery'));
    wp_enqueue_script('add-custom-js', plugin_dir_url(__FILE__) . 'js/custom.js', array('jquery'));
}

add_action('admin_enqueue_scripts', 'aad_load_scripts');

if (is_admin()) {
    //require_once (dirname(__FILE__) . '/lib/image.php');
    require_once (dirname(__FILE__) . '/admin/admin.php');
    require_once (dirname(__FILE__) . '/admin/team-class.php');
}

function myplugin_activate() {

    global $wpdb;
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    $table_name1 = $wpdb->prefix . 'packagebooking_teams';
    $table_name2 = $wpdb->prefix . 'packagebooking_league';
    $table_name3 = $wpdb->prefix . 'packagebooking_flights';
    $table_name4 = $wpdb->prefix . 'packagebooking_games';
    $table_name5 = $wpdb->prefix . 'packagebooking_hotels';
    $table_name6 = $wpdb->prefix . 'packagebooking_stadium';
    $table_name7 = $wpdb->prefix . 'packagebooking_tickets';
    $table_name8 = $wpdb->prefix . 'packagebooking_packages';


    $table1 = "CREATE TABLE IF NOT EXISTS '" . $table_name1 . "' (
  `team_id` int(12) NOT NULL AUTO_INCREMENT,
  `team_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `team_logo` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `team_photo` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `team_info` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `league_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `stadium` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `games_list` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`team_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;
        ";


    $table2 = "CREATE TABLE IF NOT EXISTS '" . $table_name2 . "' (
  `league_id` int(12) NOT NULL AUTO_INCREMENT,
  `league_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `league_logo` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `league_photo` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `league_info` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `team_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `team_logo` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`league_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";


    dbDelta($table1);
    dbDelta($table2);
}

register_activation_hook(__FILE__, 'myplugin_activate');

function myplugin_deactivate() {

    global $wpdb;

    // $table_prefix = $wpdb->prefix;
    // $wpdb->query( "DROP TABLE {$wpdb->leaguemanager_matches}" );
}

register_deactivation_hook(__FILE__, 'myplugin_deactivate');
?>
