<?php
$message = array();
if (isset($_POST['submit'])) {

    global $wpdb;
    $db_table = $wpdb->prefix . 'packagebooking_teams';

    if (empty($_POST['team_name'])) {
	$message[] = "Please enter Team Name.";
    }
    if (empty($_POST['team_info'])) {
	$message[] = "Please enter Team Info.";
    }
    //die();
    if (count($message) < 1) {
	$team_name = htmlspecialchars(strip_tags($_POST["team_name"]));
	$team_info = htmlspecialchars(strip_tags($_POST["team_info"]));
	$date_added = current_time('mysql');

	$sql = "UPDATE {$db_table} SET team_name = %s, team_info = %s WHERE id=%s";
	$prepare = $wpdb->prepare($sql, $team_name, $team_info, $_GET['team_id']);
	$wpdb->query($prepare);
	$team_id = $_GET['team_id'];
	$folder = 'teams';
	$getteam = $wpdb->get_row("SELECT  * FROM {$db_table} WHERE id =" . $_GET['team_id']);
    
	if (isset($_FILES['team_photo']) && $_FILES['team_photo']['name'] != '') {
	    $logo_file = new BookingTeamAdminPanel();
	    $field_name = 'team_photo';
	    $photo = $getteam->team_photo;
	    $sizes = array('tiny', 'thumb', 'large', 'full');
	    foreach ($sizes AS $size) {
		@unlink($logo_file->getImagePath($photo, false, $size));
	    }
	    $logo_file->uploadLogo($team_id, $_FILES['team_photo'], $overwrite = false, $folder, $db_table, $field_name);
	}
	if (isset($_FILES['team_logo']) && $_FILES['team_logo']['name'] != '') {
	    $logo_file = new BookingTeamAdminPanel();
	    $field_name = 'team_logo';
	    $image = $getteam->team_logo;
	    $sizes = array('tiny', 'thumb', 'large', 'full');
	    foreach ($sizes AS $size) {
		@unlink($logo_file->getImagePath($image, false, $size));
	    }
	    $logo_file->uploadLogo($team_id, $_FILES['team_logo'], $overwrite = false, $folder, $db_table, $field_name);
	}

	echo '<div class="success-msg">Team data Updated successfully.</div>';
    }
}
?>
<div class="wrap">
    <h2>Edit Team</h2>
    <?php
    if (count($message) > 0) {
	echo' <div class="error">';
	echo implode("<BR>", $message);
	echo '</div>';
    }
    global $wpdb;
    $table_name = $wpdb->prefix . 'packagebooking_teams';
    $select = $wpdb->get_row("SELECT  * FROM {$table_name} WHERE id=" . $_GET['team_id']);
    ?>
    <form method="post" action="" enctype="multipart/form-data">
        <input type="hidden" name="action" value="booking_add_league" />
        <div class="form-group row">
            <label for="league_name" class="col-sm-2 form-control-label">Team Name:</label>
            <div class="col-sm-6">
		<input type="text" class="form-control" id="league_name" name="team_name" value="<?php
		if (isset($_POST['team_name'])) {
		    echo $_POST['team_name'];
		} else {
		    echo $select->team_name;
		}
		?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="league_info" class="col-sm-2 form-control-label">Team Info:</label>
            <div class="col-sm-6">
                <textarea class="form-control" id="league_info" name="team_info"><?php
		    if (isset($_POST['team_name'])) {
			echo $_POST['team_info'];
		    } else {
			echo $select->team_info;
		    }
		    ?></textarea>
            </div>
        </div>
        <div class="form-group row">
            <label for="league_photo" class="col-sm-2 form-control-label">Team Photo:</label>

            <div class="col-sm-6">
		<?php
		$logo_file = new BookingTeamAdminPanel();
		if (!empty($select->team_photo)) {
		    ?>
    		<img src="<?php echo $logo_file->getImageUrl($select->team_photo, false, 'tiny', $select->id) ?>" alt="<?php _e('Logo', 'packagebooking') ?>" title="<?php _e('Logo', 'packagebooking') ?> <?php echo $select->team_photo ?>" />
		<?php } ?>
            </div>
        </div>
	<div class="form-group row">
            <label for="league_photo" class="col-sm-2 form-control-label"> Update Team Photo:</label>
            <div class="col-sm-6">
                <input type="file" class="form-control" id="league_photo" name="team_photo">
                <p>Supported file types: jpg,jpeg,png,gif</p>
            </div>
        </div>
        <div class="form-group row">
            <label for="league_logo" class="col-sm-2 form-control-label">Team Logo:</label>

            <div class="col-sm-6">
		<?php if (!empty($select->team_logo)) { ?>
    		<img src="<?php echo $logo_file->getImageUrl($select->team_logo, false, 'tiny', $select->id) ?>" alt="<?php _e('Logo', 'packagebooking') ?>" title="<?php _e('Logo', 'packagebooking') ?> <?php echo $select->team_name ?>" />
		<?php } ?>
            </div>
        </div>
	<div class="form-group row">
            <label for="league_logo" class="col-sm-2 form-control-label">Update Team Logo:</label>
            <div class="col-sm-6">
                <input type="file" class="form-control" id="league_logo" name="team_logo">
                <p>Supported file types: jpg,jpeg,png,gif</p>
            </div>
        </div>
	<?php wp_nonce_field('add_team_verify'); //prevents your form from being submitted by a user other than an admin   ?>

	<div class="form-group row">
	    <div class="col-sm-offset-2 col-sm-10">
		<input type="submit" name="submit" class="btn btn-secondary" value="Submit" />
	    </div>
	</div>
    </form>
</div>