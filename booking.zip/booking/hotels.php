<div class="full-container">

<?php if(isset($_POST['submit'])){

	global $wpdb;
	$table_name = $wpdb->prefix.'packagebooking_teams';

	$team_name	= $_POST["team_name"];	
	$team_info	= $_POST["team_info"];
	$league_name = $_POST["league_name"];
	$stadium	= $_POST["stadium"];
	$games_list	= $_POST["games_list"];

  $insert = $wpdb->insert( 
    $table_name, 
    array( 
        'team_name' => $team_name, 
        'team_info'  => $team_info,
        'league_name'     => $league_name,
        'stadium'     => $stadium,
        'games_list'     => $games_list,
        'added_date'  => current_time( 'mysql' ) 
    )
    // , 
    // array( 
    //   '%s', //data type is string
    //   '%s',
    //   '%s',
    //   '%s',
    //   '%s',
    //   '%s' 
    // ) 
  );

	if($insert) {
		echo '<div class="success-msg">New data added successfully</div>';
	}
	  
}
?>

<h2>Add New Hotels</h2>

<form method="post" action="">
  <div class="form-group row">
    <label for="team_name" class="col-sm-2 form-control-label">Team Name:</label>
    <div class="col-sm-6">
      <input type="text" class="form-control" id="team_name" name="team_name">
    </div>
  </div>
  <div class="form-group row">
    <label for="team_info" class="col-sm-2 form-control-label">Team Info:</label>
    <div class="col-sm-6">
      <textarea class="form-control" id="team_info" name="team_info"></textarea>
    </div>
  </div>
  <div class="form-group row">
    <label for="team_photo" class="col-sm-2 form-control-label">Team Photo:</label>
    <div class="col-sm-6">
      <input type="file" class="form-control" id="team_photo" name="team_photo">
    </div>
  </div>
  <div class="form-group row">
    <label for="team_logo" class="col-sm-2 form-control-label">Team Logo:</label>
    <div class="col-sm-6">
      <input type="file" class="form-control" id="team_logo" name="team_logo">
    </div>
  </div>
  <div class="form-group row">
    <label for="league_name" class="col-sm-2 form-control-label">League Name:</label>
    <div class="col-sm-6">
      <select class="form-control" id="league_name" name="league_name">
        <option value="">Select League</option>
      </select>
    </div>
  </div>
  <div class="form-group row">
    <label for="stadium" class="col-sm-2 form-control-label">Stadium:</label>
    <div class="col-sm-6">
      <select class="form-control" id="stadium" name="stadium">
        <option value="">Select Stadium</option>
      </select>
    </div>
  </div>
  <div class="form-group row">
    <label for="games_list" class="col-sm-2 form-control-label">Games List:</label>
    <div class="col-sm-6">
      <select class="form-control" id="games_list" name="games_list">
        <option value="">Select Games</option>
      </select>
    </div>
  </div>

 
  <div class="form-group row">
    <div class="col-sm-offset-2 col-sm-10">
      <input type="submit" name="submit" class="btn btn-secondary" value="Submit" />
    </div>
  </div>
</form>

</div>

<div class="full-container">
<h2>List of Hotels</h2>
<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Team Name</th>
        				<th>Team Info</th>
        				<th>League Name</th>
        				<th>Stadium</th>
        				<th>Games List</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>Team Name</th>
        				<th>Team Info</th>
        				<th>League Name</th>
        				<th>Stadium</th>
        				<th>Games List</th>
            </tr>
        </tfoot>
        <tbody>
            <?php
				global $wpdb;
				$table_name = $wpdb->prefix.'packagebooking_teams';

				$count = 1;
				$select = mysql_query("select * from $table_name order by team_id desc");
				$rowcount = mysql_num_rows($select);
				if($rowcount > 0){
					while ($row = mysql_fetch_array($select)) { ?>
					<tr>
						<td><?php echo $row['team_name']; ?></td>
						<td><?php echo $row['team_info']; ?></td>
						<td><?php echo $row['league_name']; ?></td>
						<td><?php echo $row['stadium']; ?></td>
						<td><?php echo $row['games_list']; ?></td>
					</tr>
						
					<?php }

				}else { ?>
					<tr>
						<td colspan="3"><?php _e('No data found', 'theauthor'); ?></td>
					</tr>
				<?php } ?>	
        </tbody>
    </table>
</div>