<?php
global $wpdb;
$table_name = $wpdb->prefix . 'packagebooking_league';
$booking_manager = new BookingManagerAdminPanel();
if (isset($_GET['action']) && $_GET['action'] == 'delete') {
    $wpdb->update($table_name, array("status" => 0), array("id" => $_GET['id']));
    echo '<div id="message" class="updated notice is-dismissible"><p>League data removed successfully.</p></div>';
}
?>
<div class="full-container">
    <h2>List of League</h2>

    <table id="example" title="<?php _e('List League', 'packagebooking') ?>" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>League</th>
                <th>Logo</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>ID</th>
                <th>League</th>
                <th>Logo</th>
                <th>Actions</th>
            </tr>
        </tfoot>
        <tbody>
            <?php
            $select = $wpdb->get_results("SELECT  * FROM {$table_name} WHERE status = '1' ORDER BY id DESC");

            if ($select) {
                foreach ($select as $row) {
                    ?>
                    <tr>
                        <td><?php echo $row->id; ?></td>
                        <td><?php echo $row->league_name; ?></td>
                        <td>
                            <?php if (!empty($row->league_logo)) { ?>
                                <img src="<?php echo $booking_manager->getImageUrl($row->league_logo, false, 'tiny', $row->id) ?>" alt="<?php _e('Logo', 'packagebooking') ?>" title="<?php _e('Logo', 'packagebooking') ?> <?php echo $row->league_name ?>" />
                            <?php } ?>
                        </td>
                        <td><a href="<?php echo admin_url('admin.php?page=edit-league&id=' . $row->id) ?>" title="Edit this item">Edit</a> | <a href="<?php echo admin_url('admin.php?page=add-team&subpage=team&league_id=' . $row->id) ?>" title="Add Team" >Add Teams</a> | <a href="<?php echo admin_url('admin.php?page=all-league&action=plan&id=' . $row->id) ?>" title="Plan Matches" >Plan Matches</a> | <a href="<?php echo admin_url('admin.php?page=all-league&action=delete&id=' . $row->id) ?>" title="Delete this item" >Delete</a></td>
                    </tr>

                    <?php
                }
            } else {
                ?>

            <?php } ?>
        </tbody>
    </table>

</div>
<script>
    jQuery(document).ready(function() {
        jQuery('#example').DataTable({"aoColumnDefs": [{"bSortable": false, "aTargets": [2, 3]}]});
    });
</script>
