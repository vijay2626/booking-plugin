<?php
if ((isset($_GET['action'])) && ($_GET['action'] == 'delete')) {
    $logo_file = new BookingTeamAdminPanel();
    global $wpdb;
    $db_table = $wpdb->prefix . 'packagebooking_teams';
    $getteam = $wpdb->get_row("SELECT  * FROM {$db_table} WHERE id =" . $_GET['team_id']);
    $image = $getteam->team_logo;
    $sizes = array('tiny', 'thumb', 'large', 'full');
    foreach ($sizes AS $size) {
	@unlink($logo_file->getImagePath($image, false, $size));
    }
    $photo = $getteam->team_photo;
    foreach ($sizes AS $size) {
	@unlink($logo_file->getImagePath($photo, false, $size));
    }
    $sql = "UPDATE {$db_table} SET status = %s WHERE id=%s";
    $prepare = $wpdb->prepare($sql, 0, $_GET['team_id']);
    $wpdb->query($prepare);
    echo '<div class="success-msg">Team has been deleted successfully.</div>';
}
?>
<div class="full-container">
    <h2>List of Teams</h2>
    <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Team Name</th>
                <th>Team Info</th>
                <th>Team Logo</th>
		<th>Action</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>Team Name</th>
                <th>Team Info</th>
                <th>Team Logo</th>
		<th>Action</th>
            </tr>
        </tfoot>
        <tbody>
	    <?php
	    $logo_file = new BookingTeamAdminPanel();
	    global $wpdb;
	    $table_name = $wpdb->prefix . 'packagebooking_teams';
	    $select = $wpdb->get_results("SELECT  * FROM {$table_name} WHERE status = 1 ORDER BY id DESC");

	    if ($select) {
		foreach ($select as $row) {
		    ?>
		    <tr>
			<td><?php echo $row->team_name; ?></td>
			<td><?php echo $row->team_info; ?></td>
			<td><?php if (!empty($row->team_logo)) { ?>
	    		    <img src="<?php echo $logo_file->getImageUrl($row->team_logo, false, 'tiny', $row->id) ?>" alt="<?php _e('Logo', 'packagebooking') ?>" title="<?php _e('Logo', 'packagebooking') ?> <?php echo $row->team_name ?>" />
			    <?php } ?></td>
			<td><a href="<?php echo admin_url('admin.php?page=teams&edit-team=1&team_id=' . $row->id) ?>" title="Edit this item">Edit</a> | <a href="<?php echo admin_url('admin.php?page=teams&action=delete&team_id=' . $row->id) ?>" title="Delete this item" >Delete</a></td>
		    </tr>

		    <?php
		    // Validate it if the team has any match then it will not be delete.
		}
	    } else {
		?>
    	    <tr>
    		<td colspan="3"><?php _e('No data found', 'theauthor'); ?></td>
    	    </tr>
	    <?php } ?>
        </tbody>
    </table>
</div>
<script>
    jQuery(document).ready(function () {

	jQuery('#example').DataTable({"aoColumnDefs": [{"bSortable": false, "aTargets": [2, 3]}]});
    });
</script>